/*
 * Author: Jacob Cannamela
 * Class: CSD 430
 * Assignment: CRUD JavaBeans Project
 * Date: July 12, 2025
 */


package beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MovieBean {
    private int id;
    private String title;
    private String director;
    private String genre;
    private int year;

    // --- Getters and Setters ---
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    // --- DB Connection ---
    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/CSD430",
            "student1",
            "pass"
        );
    }

    // --- Fetch all movies ---
    public static List<MovieBean> fetchAll() {
        List<MovieBean> movies = new ArrayList<>();
        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM jacob_movies_data";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                MovieBean movie = new MovieBean();
                movie.setId(rs.getInt("id"));
                movie.setTitle(rs.getString("title"));
                movie.setDirector(rs.getString("director"));
                movie.setGenre(rs.getString("genre"));
                movie.setYear(rs.getInt("release_year"));
                movies.add(movie);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return movies;
    }

    // --- Fetch one by ID ---
    public static MovieBean fetchById(int id) {
        MovieBean movie = null;
        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM jacob_movies_data WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                movie = new MovieBean();
                movie.setId(rs.getInt("id"));
                movie.setTitle(rs.getString("title"));
                movie.setDirector(rs.getString("director"));
                movie.setGenre(rs.getString("genre"));
                movie.setYear(rs.getInt("release_year"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return movie;
    }

    // --- Create a new movie ---
    public static boolean create(String title, String director, String genre, int year) {
        try (Connection conn = getConnection()) {
            String sql = "INSERT INTO jacob_movies_data (title, director, genre, release_year) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, director);
            stmt.setString(3, genre);
            stmt.setInt(4, year);
            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- Update existing movie ---
    public static boolean update(int id, String title, String director, String genre, int year) {
        try (Connection conn = getConnection()) {
            String sql = "UPDATE jacob_movies_data SET title = ?, director = ?, genre = ?, release_year = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, director);
            stmt.setString(3, genre);
            stmt.setInt(4, year);
            stmt.setInt(5, id);
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- Delete by ID ---
    public static boolean deleteById(int id) {
        try (Connection conn = getConnection()) {
            String sql = "DELETE FROM jacob_movies_data WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();
            return rowsDeleted > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
