// Name: Jacob Cannamela
// Class: CSD-430
// Date: June 28, 2025
// Module 7 Assignment

package beans;

/**
 * JavaBean representing a movie record from the database.
 * Holds fields for ID, Title, Director, Release Year, and Genre.
 */
public class MovieBean {
    private int id;
    private String title;
    private String director;
    private int release_year;
    private String genre;

    // Getter and Setter for ID
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    // Getter and Setter for Title
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    // Getter and Setter for Director
    public String getDirector() {
        return director;
    }
    public void setDirector(String director) {
        this.director = director;
    }

    // Getter and Setter for Release Year
    public int getRelease_year() {
        return release_year;
    }
    public void setRelease_year(int release_year) {
        this.release_year = release_year;
    }

    // Getter and Setter for Genre
    public String getGenre() {
        return genre;
    }
    public void setGenre(String genre) {
        this.genre = genre;
    }
}
