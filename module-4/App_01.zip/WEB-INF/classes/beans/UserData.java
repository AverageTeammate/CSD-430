/* Jacob Cannamela, CSD430 */
package beans;

import java.io.Serializable;

/**
 * UserData is a simple JavaBean that holds user feedback.
 * It implements Serializable so it can be used in JSP pages with <jsp:useBean>.
 */
public class UserData implements Serializable {

    // Private fields to hold form data
    private String name;
    private String email;
    private String favoriteColor;
    private String experienceRating;
    private String comments;

    // No-arg constructor required for JavaBeans
    public UserData() {}

    // Getter and Setter for 'name'
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for 'email'
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and Setter for 'favoriteColor'
    public String getFavoriteColor() {
        return favoriteColor;
    }

    public void setFavoriteColor(String favoriteColor) {
        this.favoriteColor = favoriteColor;
    }

    // Getter and Setter for 'experienceRating'
    public String getExperienceRating() {
        return experienceRating;
    }

    public void setExperienceRating(String experienceRating) {
        this.experienceRating = experienceRating;
    }

    // Getter and Setter for 'comments'
    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
