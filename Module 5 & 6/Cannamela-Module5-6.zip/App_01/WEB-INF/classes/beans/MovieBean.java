/**
 * Name: Jacob Cannamela
 * Description: JavaBean used to retrieve movie data from MySQL database.
 * Date: 6/21/2025
 * CSD-430
 */

package beans;

import java.sql.*;
import java.util.*;

public class MovieBean {
    private Connection conn;

    public MovieBean() throws Exception {
        // Load the MySQL driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/CSD430", "student1", "pass");
    }

    // Get all movie IDs
    public List<Integer> getMovieIds() throws SQLException {
        List<Integer> ids = new ArrayList<>();
        String query = "SELECT id FROM jacob_movies_data";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            ids.add(rs.getInt("id"));
        }
        return ids;
    }

    // Get movie by ID
    public Map<String, String> getMovieById(int id) throws SQLException {
        Map<String, String> movie = new HashMap<>();
        String query = "SELECT * FROM jacob_movies_data WHERE id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            movie.put("ID", String.valueOf(rs.getInt("id")));
            movie.put("Title", rs.getString("title"));
            movie.put("Director", rs.getString("director"));
            movie.put("Release Year", String.valueOf(rs.getInt("release_year")));
            movie.put("Genre", rs.getString("genre"));
        }
        return movie;
    }

    public void close() throws SQLException {
        if (conn != null) conn.close();
    }
}
